import { Header } from '@/components/header'
import { Hero } from '@/components/hero'
import { ModelsShowcase } from '@/components/models-showcase'
import { Configurator } from '@/components/configurator'
import { Features } from '@/components/features'
import { PricingTable } from '@/components/pricing-table'
import { ChatbotWidget } from '@/components/chatbot-widget'
import { Footer } from '@/components/footer'

export default function Home() {
  return (
    <main className="min-h-screen bg-white">
      <Header />
      <Hero />
      <ModelsShowcase />
      <Configurator />
      <Features />
      <PricingTable />
      <Footer />
      <ChatbotWidget />
    </main>
  )
}

'use client'

import { useState, useEffect } from 'react'
import { MessageCircle, X } from 'lucide-react'
import { Button } from '@/components/ui/button'

export function ChatbotWidget() {
  const [isOpen, setIsOpen] = useState(false)
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    if (isOpen && !isLoaded) {
      // Tải Botpress script
      const script = document.createElement('script')
      script.src = 'https://cdn.botpress.cloud/webchat/v3.5/shareable.html?configUrl=https://files.bpcontent.cloud/2026/01/28/11/20260128112950-66R4VNA3.json'
      script.async = true
      script.onload = () => setIsLoaded(true)
      document.body.appendChild(script)
    }
  }, [isOpen, isLoaded])

  return (
    <>
      {/* Floating Button */}
      <div className="fixed bottom-8 right-8 z-40">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className={`relative w-16 h-16 rounded-full shadow-lg transition-all duration-300 ${
            isOpen
              ? 'bg-red-600 hover:bg-red-700'
              : 'bg-blue-600 hover:bg-blue-700'
          }`}
        >
          <div className="flex items-center justify-center w-full h-full text-white">
            {isOpen ? (
              <X size={28} />
            ) : (
              <MessageCircle size={28} />
            )}
          </div>
          
          {/* Notification Badge */}
          {!isOpen && (
            <div className="absolute top-0 right-0 w-4 h-4 bg-red-500 rounded-full animate-pulse"></div>
          )}
        </button>
      </div>

      {/* Chatbot Iframe */}
      {isOpen && (
        <div className="fixed bottom-24 right-8 z-40 w-96 max-w-sm shadow-2xl rounded-lg overflow-hidden bg-white">
          <div className="bg-blue-600 text-white p-4 flex justify-between items-center">
            <h3 className="font-bold">Hỗ Trợ VinFast</h3>
            <button
              onClick={() => setIsOpen(false)}
              className="hover:bg-blue-700 p-1 rounded"
            >
              <X size={20} />
            </button>
          </div>
          
          <iframe
            src="https://cdn.botpress.cloud/webchat/v3.5/shareable.html?configUrl=https://files.bpcontent.cloud/2026/01/28/11/20260128112950-66R4VNA3.json"
            className="w-full h-96 border-0"
            allow="microphone; camera"
            title="VinFast Chatbot"
          ></iframe>
        </div>
      )}
    </>
  )
}

'use client'

import { useState } from 'react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'
import Image from 'next/image'

const carColors = [
  { name: 'Trắng Ngọc Trai', code: '#ffffff', border: '#e5e7eb' },
  { name: 'Đen Bóng', code: '#1a1a1a', border: '#666666' },
  { name: 'Xanh Đậm', code: '#0052d4', border: '#003fa8' },
  { name: 'Xám Bạc', code: '#c0c0c0', border: '#a0a0a0' },
  { name: 'Xanh Lục', code: '#10b981', border: '#059669' },
  { name: 'Cam', code: '#f97316', border: '#ea580c' },
]

const options = [
  { id: 'sunroof', label: 'Cửa sổ trời toàn cảnh', price: 50 },
  { id: 'premium-sound', label: 'Hệ thống âm thanh cao cấp', price: 75 },
  { id: 'heated-seats', label: 'Ghế nóng & Massage', price: 45 },
  { id: 'autopilot', label: 'Tự lái nâng cao', price: 120 },
  { id: 'ambient-light', label: 'Đèn môi trường thông minh', price: 30 },
  { id: 'premium-leather', label: 'Nội thất da cao cấp', price: 85 },
]

const basePrice = {
  'vf8': 102400000,
  'vf9': 173100000,
  'vf3': 48200000,
}

export function Configurator() {
  const [selectedModel, setSelectedModel] = useState('vf8')
  const [selectedColor, setSelectedColor] = useState('#ffffff')
  const [selectedOptions, setSelectedOptions] = useState<string[]>([])

  const modelNames: Record<string, string> = {
    'vf8': 'VF8',
    'vf9': 'VF9',
    'vf3': 'VF3',
  }

  const optionsPrice = selectedOptions.reduce((acc, optionId) => {
    const option = options.find(o => o.id === optionId)
    return acc + (option ? option.price * 1000000 : 0)
  }, 0)

  const totalPrice = basePrice[selectedModel as keyof typeof basePrice] + optionsPrice

  const handleOptionToggle = (optionId: string) => {
    setSelectedOptions(prev =>
      prev.includes(optionId)
        ? prev.filter(id => id !== optionId)
        : [...prev, optionId]
    )
  }

  return (
    <section id="configurator" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-4 text-center">
          Cấu Hình Xe Của Bạn
        </h2>
        <p className="text-xl text-slate-600 text-center mb-12 text-balance">
          Tùy chỉnh chiếc VinFast lý tưởng của bạn
        </p>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Preview Section */}
          <Card className="p-8 bg-gradient-to-br from-slate-50 to-slate-100 flex flex-col items-center justify-center">
            <div className="w-full h-96 mb-6 bg-white rounded-lg shadow-md p-4 flex items-center justify-center">
              <div
                className="text-center"
                style={{
                  background: selectedColor,
                  width: '200px',
                  height: '120px',
                  borderRadius: '8px',
                  border: '2px solid #ddd',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  transition: 'all 0.3s ease',
                }}
              >
                <p className="text-white font-bold drop-shadow-lg">
                  {modelNames[selectedModel]}
                </p>
              </div>
            </div>

            {/* Color Selector */}
            <div className="w-full">
              <h3 className="font-bold text-lg mb-4 text-slate-900">Chọn Màu Sắc</h3>
              <div className="grid grid-cols-3 gap-4">
                {carColors.map((color) => (
                  <button
                    key={color.code}
                    onClick={() => setSelectedColor(color.code)}
                    className={`p-3 rounded-lg text-center transition-all ${
                      selectedColor === color.code
                        ? 'ring-2 ring-blue-600 ring-offset-2'
                        : 'border-2 border-slate-200'
                    }`}
                  >
                    <div
                      className="w-full h-12 rounded mb-2"
                      style={{
                        backgroundColor: color.code,
                        border: color.border ? `2px solid ${color.border}` : '2px solid #ccc',
                      }}
                    ></div>
                    <p className="text-xs font-medium text-slate-700">{color.name}</p>
                  </button>
                ))}
              </div>
            </div>
          </Card>

          {/* Configuration Section */}
          <div className="space-y-6">
            {/* Model Selection */}
            <Card className="p-6">
              <h3 className="font-bold text-lg mb-4 text-slate-900">Chọn Dòng Xe</h3>
              <div className="space-y-3">
                {['vf8', 'vf9', 'vf3'].map((model) => (
                  <label
                    key={model}
                    className={`flex items-center p-4 rounded-lg border-2 cursor-pointer transition ${
                      selectedModel === model
                        ? 'border-blue-600 bg-blue-50'
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <input
                      type="radio"
                      name="model"
                      value={model}
                      checked={selectedModel === model}
                      onChange={(e) => setSelectedModel(e.target.value)}
                      className="mr-4"
                    />
                    <div>
                      <p className="font-semibold text-slate-900">{modelNames[model]}</p>
                      <p className="text-sm text-slate-600">
                        {model === 'vf8' && 'SUV Thể Thao Đa Dụng'}
                        {model === 'vf9' && 'SUV Hạng D Hạng Sang'}
                        {model === 'vf3' && 'Hatchback Thành Phố'}
                      </p>
                    </div>
                  </label>
                ))}
              </div>
            </Card>

            {/* Options */}
            <Card className="p-6">
              <h3 className="font-bold text-lg mb-4 text-slate-900">Tùy Chọn Bổ Sung</h3>
              <div className="space-y-3">
                {options.map((option) => (
                  <label
                    key={option.id}
                    className="flex items-center p-3 rounded-lg border border-slate-200 hover:bg-slate-50 cursor-pointer transition"
                  >
                    <Checkbox
                      checked={selectedOptions.includes(option.id)}
                      onCheckedChange={() => handleOptionToggle(option.id)}
                      className="mr-3"
                    />
                    <div className="flex-1">
                      <p className="font-medium text-slate-900">{option.label}</p>
                    </div>
                    <p className="text-blue-600 font-bold">+{option.price}M</p>
                  </label>
                ))}
              </div>
            </Card>

            {/* Price Summary */}
            <Card className="p-6 bg-gradient-to-r from-blue-600 to-blue-700 text-white">
              <h3 className="font-bold text-lg mb-4">Tổng Giá</h3>
              <div className="space-y-2 mb-6 text-blue-100">
                <div className="flex justify-between">
                  <span>Giá xe {modelNames[selectedModel]}:</span>
                  <span>{(basePrice[selectedModel as keyof typeof basePrice] / 1000000).toFixed(1)}M</span>
                </div>
                {selectedOptions.length > 0 && (
                  <div className="flex justify-between">
                    <span>Tùy chọn bổ sung:</span>
                    <span>+{(optionsPrice / 1000000).toFixed(1)}M</span>
                  </div>
                )}
                <div className="border-t border-blue-400 pt-2 flex justify-between font-bold text-lg">
                  <span>Tổng cộng:</span>
                  <span>{(totalPrice / 1000000).toFixed(1)}M</span>
                </div>
              </div>
              <Button className="w-full bg-white text-blue-600 hover:bg-blue-50 font-bold">
                Đặt Hàng Ngay
              </Button>
            </Card>
          </div>
        </div>
      </div>
    </section>
  )
}

'use client'

import { Card } from '@/components/ui/card'
import { Zap, Shield, TrendingUp, Cpu, Leaf, Smartphone } from 'lucide-react'
import Image from 'next/image'

const features = [
  {
    icon: Zap,
    title: 'Công Nghệ Pin Tối Tân',
    description: 'Pin LFP an toàn, tuổi thọ lâu dài lên đến 10 năm với dung lượng lớn',
  },
  {
    icon: Shield,
    title: 'An Toàn Hàng Đầu',
    description: 'Hệ thống an toàn chủ động và bị động kiến tạo nên chiếc xe an toàn nhất',
  },
  {
    icon: Cpu,
    title: 'Công Nghệ Tự Lái',
    description: 'Bộ xử lý trí tuệ nhân tạo cho khả năng tự lái thông minh',
  },
  {
    icon: TrendingUp,
    title: 'Hiệu Năng Vượt Trội',
    description: 'Động cơ điện hiệu suất cao cho trải nghiệm lái thể thao',
  },
  {
    icon: Leaf,
    title: 'Thân Thiện Với Môi Trường',
    description: 'Zero khí thải, đóng góp bảo vệ môi trường xanh',
  },
  {
    icon: Smartphone,
    title: 'Kết Nối Thông Minh',
    description: 'Ứng dụng di động điều khiển toàn bộ các chức năng xe',
  },
]

export function Features() {
  return (
    <section id="features" className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-4">
            Tính Năng Nổi Bật
          </h2>
          <p className="text-xl text-slate-600 text-balance">
            Khám phá những công nghệ tiên tiến trên VinFast
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {features.map((feature, idx) => {
            const Icon = feature.icon
            return (
              <Card key={idx} className="p-8 hover:shadow-lg transition-shadow group">
                <div className="w-14 h-14 bg-blue-600/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-blue-600/20 transition">
                  <Icon className="text-blue-600" size={28} />
                </div>
                <h3 className="font-bold text-lg text-slate-900 mb-2">{feature.title}</h3>
                <p className="text-slate-600">{feature.description}</p>
              </Card>
            )
          })}
        </div>

        {/* Image Section */}
        <div className="grid lg:grid-cols-2 gap-8 items-center">
          <div className="relative h-96 bg-slate-200 rounded-lg overflow-hidden shadow-lg">
            <Image
              src="/images/charging-solution.jpg"
              alt="Giải pháp sạc"
              width={500}
              height={400}
              className="w-full h-full object-cover"
            />
          </div>
          <div>
            <h3 className="text-3xl font-bold text-slate-900 mb-6">
              Giải Pháp Sạc Toàn Diện
            </h3>
            <ul className="space-y-4">
              {[
                'Cáp sạc tương thích AC và DC',
                'Hỗ trợ sạc siêu nhanh tại nhà',
                'Mạng trạm sạc công cộng phát triển',
                'Ứng dụng tìm trạm sạc gần nhất',
              ].map((item, idx) => (
                <li key={idx} className="flex items-center gap-3">
                  <span className="w-2 h-2 bg-green-600 rounded-full"></span>
                  <span className="text-slate-700">{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  )
}

'use client'

import { Facebook, Instagram, Twitter, Linkedin, Phone, Mail, MapPin } from 'lucide-react'

export function Footer() {
  return (
    <footer className="bg-slate-900 text-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          {/* Company Info */}
          <div>
            <h3 className="text-xl font-bold text-white mb-4">VinFast</h3>
            <p className="text-sm text-slate-400 mb-4">
              Công ty hàng đầu trong sản xuất và phân phối xe điện tại Việt Nam
            </p>
            <div className="flex gap-4">
              <a href="#" className="hover:text-blue-400 transition">
                <Facebook size={20} />
              </a>
              <a href="#" className="hover:text-blue-400 transition">
                <Instagram size={20} />
              </a>
              <a href="#" className="hover:text-blue-400 transition">
                <Twitter size={20} />
              </a>
              <a href="#" className="hover:text-blue-400 transition">
                <Linkedin size={20} />
              </a>
            </div>
          </div>

          {/* Products */}
          <div>
            <h4 className="font-bold text-white mb-4">Dòng Xe</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#models" className="hover:text-blue-400 transition">
                  VF8
                </a>
              </li>
              <li>
                <a href="#models" className="hover:text-blue-400 transition">
                  VF9
                </a>
              </li>
              <li>
                <a href="#models" className="hover:text-blue-400 transition">
                  VF3
                </a>
              </li>
              <li>
                <a href="#configurator" className="hover:text-blue-400 transition">
                  Cấu hình xe
                </a>
              </li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="font-bold text-white mb-4">Hỗ Trợ</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#" className="hover:text-blue-400 transition">
                  Tư vấn mua hàng
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-blue-400 transition">
                  Hướng dẫn sử dụng
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-blue-400 transition">
                  Bảo hành & Bảo dưỡng
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-blue-400 transition">
                  Câu hỏi thường gặp
                </a>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-bold text-white mb-4">Liên Hệ</h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-center gap-2">
                <Phone size={16} className="text-blue-400" />
                <a href="tel:+84123456789" className="hover:text-blue-400 transition">
                  1900 1234
                </a>
              </li>
              <li className="flex items-center gap-2">
                <Mail size={16} className="text-blue-400" />
                <a href="mailto:info@vinfast.com" className="hover:text-blue-400 transition">
                  info@vinfast.com
                </a>
              </li>
              <li className="flex items-start gap-2">
                <MapPin size={16} className="text-blue-400 mt-1" />
                <span>Phố Quyết Thắng, phường Phúc Đồng, Hà Nội</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-slate-700 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-slate-400">
              © 2024 VinFast. Tất cả quyền được bảo lưu.
            </p>
            <div className="flex gap-6 mt-4 md:mt-0 text-sm text-slate-400">
              <a href="#" className="hover:text-blue-400 transition">
                Chính sách bảo mật
              </a>
              <a href="#" className="hover:text-blue-400 transition">
                Điều khoản sử dụng
              </a>
              <a href="#" className="hover:text-blue-400 transition">
                Chính sách cookie
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}

'use client'

import { useState } from 'react'
import { Menu, X } from 'lucide-react'
import { Button } from '@/components/ui/button'

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-slate-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center">
            <div className="text-2xl font-bold text-blue-600">VinFast</div>
            <div className="ml-2 text-sm text-slate-600 font-medium">Xe Điện</div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex gap-8">
            <a href="#models" className="text-slate-700 hover:text-blue-600 font-medium transition">
              Dòng xe
            </a>
            <a href="#configurator" className="text-slate-700 hover:text-blue-600 font-medium transition">
              Cấu hình
            </a>
            <a href="#features" className="text-slate-700 hover:text-blue-600 font-medium transition">
              Tính năng
            </a>
            <a href="#pricing" className="text-slate-700 hover:text-blue-600 font-medium transition">
              Giá bán
            </a>
          </nav>

          {/* CTA Button */}
          <div className="hidden md:block">
            <Button className="bg-blue-600 hover:bg-blue-700 text-white">
              Liên hệ tư vấn
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden pb-4 space-y-3">
            <a href="#models" className="block text-slate-700 hover:text-blue-600 font-medium">
              Dòng xe
            </a>
            <a href="#configurator" className="block text-slate-700 hover:text-blue-600 font-medium">
              Cấu hình
            </a>
            <a href="#features" className="block text-slate-700 hover:text-blue-600 font-medium">
              Tính năng
            </a>
            <a href="#pricing" className="block text-slate-700 hover:text-blue-600 font-medium">
              Giá bán
            </a>
            <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white mt-2">
              Liên hệ tư vấn
            </Button>
          </nav>
        )}
      </div>
    </header>
  )
}

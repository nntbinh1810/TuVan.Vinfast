'use client'

import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import Image from 'next/image'

const models = [
  {
    id: 'vf8',
    name: 'VF8',
    subtitle: 'SUV Thể Thao Đa Dụng',
    price: '1.024 - 1.261 Tỷ',
    image: '/images/vf8-model.jpg',
    specs: [
      { label: 'Quãng đường', value: '561 km' },
      { label: 'Công suất', value: '400 HP' },
      { label: '0-100 km/h', value: '6.0s' },
    ],
    features: [
      'Động cơ điện hiệu suất cao',
      'Hệ thống an toàn 5 sao',
      'Nội thất cao cấp',
      'Công nghệ tự lái tiên tiến',
    ],
  },
  {
    id: 'vf9',
    name: 'VF9',
    subtitle: 'SUV Hạng D Hạng Sang',
    price: '1.731 - 1.968 Tỷ',
    image: '/images/vf9-model.jpg',
    specs: [
      { label: 'Quãng đường', value: '634 km' },
      { label: 'Công suất', value: '503 HP' },
      { label: '0-100 km/h', value: '5.9s' },
    ],
    features: [
      'Nội thất 7 chỗ cao cấp',
      'Công nghệ pin bền nhất',
      'Hệ thống giải trí thông minh',
      'An toàn không đối thủ',
    ],
  },
  {
    id: 'vf3',
    name: 'VF3',
    subtitle: 'Hatchback Thành Phố Thông Minh',
    price: '482 - 585 Triệu',
    image: '/images/vf3-model.jpg',
    specs: [
      { label: 'Quãng đường', value: '405 km' },
      { label: 'Công suất', value: '147 HP' },
      { label: '0-100 km/h', value: '9.9s' },
    ],
    features: [
      'Thiết kế nhỏ gọn, thời trang',
      'Tiết kiệm điện tối ưu',
      'Nội thất thoáng sáng',
      'Phù hợp đi lại thành phố',
    ],
  },
]

export function ModelsShowcase() {
  return (
    <section id="models" className="py-20 bg-gradient-to-b from-slate-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-4">
            Bộ Sưu Tập Xe Điện VinFast
          </h2>
          <p className="text-xl text-slate-600 text-balance">
            Khám phá các dòng xe điện đổi mới từ VinFast
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {models.map((model) => (
            <Card
              key={model.id}
              className="overflow-hidden hover:shadow-lg transition-shadow group"
            >
              {/* Image */}
              <div className="relative h-64 bg-slate-200 overflow-hidden">
                <Image
                  src={model.image}
                  alt={model.name}
                  width={400}
                  height={300}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="text-2xl font-bold text-slate-900 mb-1">
                  {model.name}
                </h3>
                <p className="text-slate-600 mb-4">{model.subtitle}</p>
                
                {/* Specs */}
                <div className="grid grid-cols-3 gap-3 mb-6 pb-6 border-b border-slate-200">
                  {model.specs.map((spec, idx) => (
                    <div key={idx} className="text-center">
                      <p className="text-blue-600 font-bold text-lg">{spec.value}</p>
                      <p className="text-xs text-slate-600">{spec.label}</p>
                    </div>
                  ))}
                </div>

                {/* Features */}
                <ul className="space-y-2 mb-6">
                  {model.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-green-600 font-bold text-lg mt-0.5">✓</span>
                      <span className="text-slate-700">{feature}</span>
                    </li>
                  ))}
                </ul>

                {/* Price and Button */}
                <div className="space-y-4">
                  <div>
                    <p className="text-slate-600 text-sm">Giá từ</p>
                    <p className="text-2xl font-bold text-blue-600">{model.price}</p>
                  </div>
                  <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold">
                    Chi tiết & Cấu hình
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

'use client'

import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Check } from 'lucide-react'

const pricingData = [
  {
    model: 'VF3',
    category: 'Hatchback Thành Phố',
    basePrice: '482',
    colors: ['Trắng', 'Đen', 'Xanh'],
    specs: {
      'Quãng đường': '405 km',
      'Công suất': '147 HP',
      'Thời gian sạc': '10 giờ (220V)',
      'Kích thước': '3.614 x 1.619 x 1.545 m',
      'Số chỗ ngồi': '5 chỗ',
    },
    features: [
      'Cảm biến va chạm phía trước & sau',
      'Camera lùi 360°',
      'Ghế chỉnh điện',
      'Hệ thống âm thanh cơ bản',
      'Kết nối Bluetooth',
      'Nội thất da tổng hợp',
    ],
  },
  {
    model: 'VF8',
    category: 'SUV Thể Thao Đa Dụng',
    basePrice: '1.024 - 1.261',
    isPopular: true,
    colors: ['Trắng', 'Đen', 'Xanh', 'Xám', 'Cam'],
    specs: {
      'Quãng đường': '561 km',
      'Công suất': '400 HP',
      'Thời gian sạc': '6 giờ (DC siêu nhanh)',
      'Kích thước': '4.713 x 1.860 x 1.617 m',
      'Số chỗ ngồi': '5 chỗ',
    },
    features: [
      'Hệ thống an toàn 5 sao',
      'Đèn LED chiếu sáng toàn cảnh',
      'Cửa sổ trời toàn cảnh',
      'Ghế nóng massage',
      'Hệ thống âm thanh cao cấp',
      'Nội thất da cao cấp',
      'Tự lái nâng cao',
      'Hệ thống hẹn giờ sạc thông minh',
    ],
  },
  {
    model: 'VF9',
    category: 'SUV Hạng D Hạng Sang',
    basePrice: '1.731 - 1.968',
    colors: ['Trắng', 'Đen', 'Xanh', 'Xám'],
    specs: {
      'Quãng đường': '634 km',
      'Công suất': '503 HP (Dual Motor)',
      'Thời gian sạc': '6.2 giờ (DC siêu nhanh)',
      'Kích thước': '4.886 x 1.927 x 1.686 m',
      'Số chỗ ngồi': '7 chỗ',
    },
    features: [
      'Nội thất 7 chỗ cao cấp',
      'Hàng ghế thứ ba có thể gập',
      'Hệ thống âm thanh Harman Kardon',
      'Cửa sổ trời toàn cảnh kép',
      'Phanh tay điện tử tự động',
      'Cảm biến mưa tự động',
      'Tự lái tiên tiến với radar',
      'Camera 360° 4K',
    ],
  },
]

export function PricingTable() {
  return (
    <section id="pricing" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-4">
            Giá Bán & Thông Số Kỹ Thuật
          </h2>
          <p className="text-xl text-slate-600 text-balance">
            So sánh chi tiết các dòng xe VinFast
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {pricingData.map((car, idx) => (
            <Card
              key={idx}
              className={`overflow-hidden transition-all ${
                car.isPopular ? 'ring-2 ring-blue-600 shadow-xl lg:scale-105' : ''
              }`}
            >
              {/* Popular Badge */}
              {car.isPopular && (
                <div className="bg-blue-600 text-white text-center py-2 font-bold">
                  Mẫu Phổ Biến Nhất
                </div>
              )}

              {/* Header */}
              <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-6">
                <h3 className="text-3xl font-bold mb-2">{car.model}</h3>
                <p className="text-blue-100 mb-4">{car.category}</p>
                <p className="text-3xl font-bold">
                  {car.basePrice}
                  <span className="text-lg"> Triệu</span>
                </p>
              </div>

              {/* Content */}
              <div className="p-6">
                {/* Màu sắc */}
                <div className="mb-6">
                  <p className="font-semibold text-slate-900 mb-2">Màu Sắc Có Sẵn:</p>
                  <div className="flex flex-wrap gap-2">
                    {car.colors.map((color, i) => (
                      <span
                        key={i}
                        className="px-3 py-1 bg-slate-100 text-slate-700 text-sm rounded-full"
                      >
                        {color}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Specifications */}
                <div className="mb-6 pb-6 border-b border-slate-200">
                  <p className="font-semibold text-slate-900 mb-3">Thông Số Kỹ Thuật:</p>
                  <div className="space-y-2 text-sm">
                    {Object.entries(car.specs).map(([key, value]) => (
                      <div key={key} className="flex justify-between">
                        <span className="text-slate-600">{key}:</span>
                        <span className="font-medium text-slate-900">{value}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Features */}
                <div className="mb-6">
                  <p className="font-semibold text-slate-900 mb-3">Tính Năng:</p>
                  <ul className="space-y-2">
                    {car.features.map((feature, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-slate-700">
                        <Check className="text-green-600 flex-shrink-0 mt-0.5" size={16} />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* CTA Button */}
                <Button
                  className={`w-full font-bold py-2 ${
                    car.isPopular
                      ? 'bg-blue-600 hover:bg-blue-700 text-white'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-900'
                  }`}
                >
                  {car.isPopular ? 'Đặt Hàng Ngay' : 'Yêu Cầu Tư Vấn'}
                </Button>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
